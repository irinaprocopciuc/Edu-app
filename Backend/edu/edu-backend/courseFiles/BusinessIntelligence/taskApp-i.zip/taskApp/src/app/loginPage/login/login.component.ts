import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  @ViewChild('uname')  uname: ElementRef;
  @ViewChild('pass') pass: ElementRef;

  constructor(private http: HttpClient, private toastr: ToastrService, private router: Router) { }

  ngOnInit(): void { }

  public login(): void{

    let uname = this.uname.nativeElement.value;
    let pass = this.pass.nativeElement.value;
    let body = {username: uname, password: pass};

    if(uname !== '' && uname !== null && pass !== '' && pass !== null ){
      this.http.post('http://localhost:8080/login/checkUser',body,{responseType: 'json'} ).subscribe(
      data =>{
        if(data['code']==200){
          console.log(data['status'] + ' Succefuly logged on');
          localStorage.setItem('username',uname);
          localStorage.setItem('userID',data['userID']);
        }else{
          this.toastr.error('Login problems, returning other status then 200 when it shouldn\'t!');
        }
      }
      ,
      error=>{
        this.toastr.error(error.error['message']);
      })
    }else{
      this.toastr.error('Enter credentials fgt');
    }
    this.router.navigateByUrl('/main');
  }

  public registerPage():void{
    this.router.navigateByUrl('/register')
  }

}
