import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

type Task = {
  taskId: string;
  pbiId: string;
  name: string;
  subTask: string;
};

@Component({
  selector: 'app-main-page',
  templateUrl: './main-page.component.html',
  styleUrls: ['./main-page.component.scss'],
})
export class MainPageComponent implements OnInit {
  constructor(
    private http: HttpClient,
    private toastr: ToastrService,
    private router: Router
  ) {}

  tasks: Task[];
  taskDetails: Task;
  isEmpty = false;

  ngOnInit(): void {
    this.getTasks();
  }

  public goHome(): void {
    this.router.navigateByUrl('/login');
  }

  private getTasks(): void {
    this.http
      .get(
        'http://localhost:8080/mainPage/getTasks/userID=' +
          localStorage.getItem('userID'),
        { responseType: 'json' }
      )
      .subscribe(
        (data) => {
          if (data['code'] == 200) {
            this.tasks = data['response'];
            console.log(this.tasks);
          } else {
            this.toastr.error('WTF!!!');
          }
        },
        (error) => {
          this.toastr.error(error.error['message']);
        }
      );
  }

  private getTaskDetails(taskId: string): void {
    

    this.http
      .get('http://localhost:8080/mainPage/getTasks/taskID=' + taskId, {
        responseType: 'json',
      })
      .subscribe(
        (data) => {
          if (data['code'] == 200) {
            this.taskDetails = data['response'];
          } else {
            this.toastr.error('WTF!!!');
          }
        },
        (error) => {
          this.toastr.error(error.error['message']);
        }
      );
  }

  public showTaskDetails(taskId: string): void {
    this.isEmpty = true;
    this.getTaskDetails(taskId);
    console.log(this.taskDetails);
  }
}
