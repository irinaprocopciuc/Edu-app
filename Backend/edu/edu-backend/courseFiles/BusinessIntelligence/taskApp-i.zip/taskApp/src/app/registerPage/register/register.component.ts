import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  @ViewChild('uname')  uname: ElementRef;
  @ViewChild('pass') pass: ElementRef;
  @ViewChild('pass') repass: ElementRef;

  constructor(private http: HttpClient, private toastr: ToastrService, private router: Router) { }

  ngOnInit(): void {
  }

  public register(): void{
    
    let uname = this.uname.nativeElement.value;
    let pass = this.pass.nativeElement.value;
    let repass = this.repass.nativeElement.value;

    let body = {username: uname, password: pass, repassword: pass};

    if(uname !== '' && uname !== null && pass !== '' && pass !== null && repass !== '' && repass !== null ){
      this.http.post('http://localhost:8080/register/registerUser',body,{responseType: 'json'} ).subscribe(
      data =>{
        if(data['code']==200){
          console.log(data['status'] + ' Succefuly registered');
          this.router.navigateByUrl('/login');
        }else{
          this.toastr.error('Register problems, returning other status then 200 when it shouldn\'t!');
        }
      }
      ,
      error=>{
        this.toastr.error(error.error['message']+'! Error code: '+error.error['code']);
      })
    }else{
      this.toastr.error('Enter credentials fgt');
    }
  }

  public loginPage():void{
    this.router.navigateByUrl('/login')
  }

}
